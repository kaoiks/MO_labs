import numpy as np
import cvxpy as cp
import csv
import matplotlib.pyplot as plt

data = csv.reader(open('data01.csv', 'r'), delimiter=',')
x_values = []
y_values = []
for row in data:
    x_values.append(float(row[0]))
    y_values.append(float(row[1]))

plt.scatter(x_values, y_values, color='r')
plt.xlim(0, 10)
plt.ylim(-50, 150)
plt.grid(True)
plt.yticks(range(-50, 150 + 1, 50))
plt.show()

a1 = cp.Variable()
b1 = cp.Variable()
a2 = cp.Variable()
b2 = cp.Variable()


# objective = cp.Minimize(100 * s1 + 199.90 * s2 + 700 * l1 + 800 * l2 - 6500 * l1 - 7100 * l2)
# constraints = [
#     0.01 * s1 + 0.02 * s2 - 0.5 * l1 - 0.6 * l2 >= 0,
#     s1 + s2 <= 1000,
#     90 * l1 + 100 * l2 <= 2000,
#     40 * l1 + 50 * l2 <= 800,
#     100 * s1 + 199.90 * s2 + 700 * l1 + 800 * l2 <= 100000,
#     s1 >= 0,
#     s2 >= 0,
#     l1 >= 0,
#     l2 >= 0,
# ]
# p1 = cp.Problem(objective, constraints)
# p1.solve()
# print("--------------")
# print(round(float(s1.value), 3))
# print(round(float(s2.value), 3))
# print(round(float(l1.value), 3))
# print(round(float(l2.value), 3))
# print("--------------")

